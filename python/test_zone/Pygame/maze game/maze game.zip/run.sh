python3 maze.py
