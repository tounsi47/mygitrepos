echo "installing required depencies for the game (for your linux mint :)"
echo "first, you have to authenciate"
sudo apt install python3-pygame
echo "it seen that we finish, any errors ??"

